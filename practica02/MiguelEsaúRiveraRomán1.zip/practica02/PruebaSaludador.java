//10:24-26/08/2022
//Rivera Román Miguel Esaú
//Método principal de la clase "Saludador"

public class PruebaSaludador{
	//metodo pricipal(main)
	public static void main (String[]args){
		//creando una instancia del Objeto saludador 
		Saludador alumno = new Saludador();
		//accediendo al método saludar del alumno
		alumno.saludar();
	}
}
