//10:09-26/08/2022
//Rivera Román Miguel Esaú
//Programa que ejecute un hola mundo orientado a objetos

//Definición de la clase

public class Saludador{
	//Método para saludar
	public void saludar(){//llave que inicia el método
		System.out.println("Hola Alumno de POO");
	}//llave que cierra el método de saludar
}//llave que cierra la clase